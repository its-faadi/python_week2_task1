import random  # Import the random module to generate a random number

def main():
    # Generate a random secret number between -100 and 50
    secret_number = random.randint(-100, 50)
    attempts = 0  # Initialize the number of attempts to zero

    while True:
        try:
            # Prompt the user to guess the number
            guess = int(input("Guess the number between -100 and 50: "))
            attempts += 1  # Increment the number of attempts

            if guess < secret_number:
                print("Your guess is too low. Try again.")  # Inform the user if the guess is too low
            elif guess > secret_number:
                print("Your guess is too high. Try again.")  # Inform the user if the guess is too high
            else:
                # Congratulate the user and display the number of attempts
                print(f"Congratulations! You guessed the number in {attempts} attempts.")
                break  # Break out of the loop when the correct number is guessed
        except ValueError:
            # Handle invalid input (non-integer values)
            print("Invalid input. Please enter an integer.")

if __name__ == "__main__":
    main()  # Call the main function to start the game
